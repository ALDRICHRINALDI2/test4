package android.projectcy.weatherapicom;

public class Setting {
    public String forecast = "http://api.weatherapi.com/v1/forecast.json";
    public String current = "http://api.weatherapi.com/v1/current.json?key=4bc8cfe44b324366909170149210706&q=Jakarta&aqi=yes";
}
